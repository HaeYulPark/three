import { GoogleGenAI, Type, SchemaType } from "@google/genai";
import { GeneratedQuest } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateDailyQuests = async (): Promise<GeneratedQuest[]> => {
  if (!apiKey) {
    console.warn("API Key is missing. Returning fallback data.");
    return fallbackQuests;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "집에서 혼자 할 수 있는 재미있고 생산적인 퀘스트 3가지를 생성해줘. 난이도는 쉬움(1), 보통(2), 어려움(3)으로 구성해줘. 한국어로 작성해줘.",
      config: {
        systemInstruction: "You are a fun lifestyle coach app called 'Zipkok Quest'. Your goal is to give users small, achievable, but meaningful tasks to do at home.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "퀘스트 제목 (예: 난이도 1)" },
              content: { type: Type.STRING, description: "구체적인 할 일 내용" },
              difficulty: { type: Type.STRING, description: "Level 1, 2, or 3" }
            },
            required: ["title", "content", "difficulty"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) return fallbackQuests;
    
    const data = JSON.parse(text) as GeneratedQuest[];
    return data;

  } catch (error) {
    console.error("Failed to generate quests:", error);
    return fallbackQuests;
  }
};

const fallbackQuests: GeneratedQuest[] = [
  {
    title: "난이도 1 (기본)",
    content: "일어나서 침구 정리하고 물 한 잔 마시기!",
    difficulty: "1"
  },
  {
    title: "난이도 2 (활동)",
    content: "좋아하는 음악 틀고 10분간 스트레칭 하기!",
    difficulty: "2"
  },
  {
    title: "난이도 3 (도전)",
    content: "냉장고에 있는 재료로 새로운 요리 시도해보기!",
    difficulty: "3"
  }
];